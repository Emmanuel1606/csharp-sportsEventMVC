﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SportsAppMVC.Models
{
    public class UserModel
    {
            public int ID { get; set; }
            public string Name { get; set; }
            public DateTime? DateOfBirth { get; set; }
            public string Gender { get; set; }
            public string Email { get; set; }
            public string Address { get; set; }
            public string Postalcode { get; set; }
            public string TelNo { get; set; }
            public string LocationOfWork { get; set; }
            public string Biography { get; set; }
            public string KeySkills { get; set; }
            public SportsType? Type { get; set; }

    }
}
