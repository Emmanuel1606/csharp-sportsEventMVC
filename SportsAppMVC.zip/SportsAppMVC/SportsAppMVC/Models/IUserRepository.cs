﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SportsAppMVC.Models
{
    public interface IUserRepository
        {
             
            UserModel GetUser(int Id);
            IEnumerable<UserModel> GetAll();
            UserModel AddUsers(UserModel addUsers);
            UserModel Update(UserModel editDetails);
            UserModel Delete(int Id);

        }
}
