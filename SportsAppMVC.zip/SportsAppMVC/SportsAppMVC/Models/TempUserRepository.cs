﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SportsAppMVC.Models
{
    public class TempUserRepository : IUserRepository
    {
        private List<UserModel> usersList;

        public TempUserRepository()
        {
            usersList = new List<UserModel>()
            {
                new UserModel(){
                ID= 1,
                Name="Harry",
                DateOfBirth= DateTime.Now,
                Gender="Male",
                Email="a@gmail.com",
                TelNo= 0011,
                Address="10 HighBury Lane",
                Postalcode = "SE7 7NP",
                LocationOfWork="Canary Wharf, London",
                Biography="I am kind of a genius",
                KeySkills="Entrepeneur",
                }
            };

        }

        public UserModel AddUser(UserModel addUser)
        {
            addUser.ID = usersList.Max(x => x.ID) + 1;
            usersList.Add(addUser);
            return addUser;
        }

        //Get All Users
        public IEnumerable<UserModel> GetAll()
        {
            return usersList;
        }

    }
}
