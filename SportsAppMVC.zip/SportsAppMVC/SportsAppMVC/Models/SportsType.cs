﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SportsAppMVC.Models
{
    public enum SportsType
    {
        Football,
        Basketball,
        Rugby,
        Tennis,
        Golf,
        Cricket,
        Baseball,
        Volleyball
        
        
    }
}
