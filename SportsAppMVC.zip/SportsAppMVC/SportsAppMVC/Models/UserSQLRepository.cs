﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SportsAppMVC.Models
{
    public class UserSQLRepository : IUserRepository
    {
        private readonly ApplicationDbContext context;
        public UserSQLRepository(ApplicationDbContext context)
        {
            this.context = context;
        }

        public IEnumerable<UserModel> GetAll()
        {
           return context.Users;
        }

        public UserModel AddUsers(UserModel addUsers)
        {
            context.Users.Add(addUsers);
            context.SaveChanges();
            return addUsers;
        }

        public UserModel GetUser(int iD)
        {
            return context.Users.Find(iD);
        }

        public UserModel Delete(int iD)
        {
            UserModel user = context.Users.Find(iD);
            if (user != null)
            {
                context.Remove(user);
                context.SaveChanges();
            }
            return user;

        }

        public UserModel Update(UserModel editDetails)
        {
            var user = context.Users.Attach(editDetails);
            user.State = Microsoft.EntityFrameworkCore.EntityState.Modified;
            context.SaveChanges();
            return editDetails;
        }


    }
}
