﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using SportsAppMVC.Models;
using SportsAppMVC.VM;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace SportsAppMVC.Controllers
{
    [Authorize]
    public class AccountController : Controller
    {
        private readonly UserManager<IdentityUser> userManager;
        private  SignInManager<IdentityUser> signInManager;

        private IUserRepository userRepository;

        public AccountController(UserManager<IdentityUser> userManager,
                                 SignInManager<IdentityUser> signInManager, IUserRepository userRepository)
        {
            this.userManager = userManager;
            this.signInManager = signInManager;
            this.userRepository = userRepository;
        }

        public IActionResult Index()
        {

            var users = userRepository.GetAll();
            return View(users);

        }

        public IActionResult Details(int Id)
        {
            ViewUserDetailsVM viewUserDetailsVM = new ViewUserDetailsVM()
            {
                User = userRepository.GetUser(Id),
                PageTitle = "User Details"
            };

            return View(viewUserDetailsVM);
        }

        [HttpGet]
        public ViewResult Add()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Add(NewUserModelVM userViewModel)
        {
            if (ModelState.IsValid)
            {
                UserModel newUser = new UserModel()
                {
                    Name = userViewModel.Name,
                    DateOfBirth = userViewModel.DateOfBirth,
                    Gender = userViewModel.Gender,
                    Email = userViewModel.Email,
                    Address = userViewModel.Address,
                    Postalcode = userViewModel.Postalcode,
                    TelNo = userViewModel.TelNo,
                    LocationOfWork = userViewModel.LocationOfWork,
                    Biography = userViewModel.Biography,
                    KeySkills = userViewModel.KeySkills,
                    Type = userViewModel.Type
                };
                userRepository.AddUsers(newUser);
                // return RedirectToAction("Details", new { id = newUser.ID });
                return Redirect("Index");
            }
            return View();
        }
        [HttpGet]
        public ViewResult Edit(int Id)
        {
            UserModel user = userRepository.GetUser(Id);
            UserEditVM userEditVM = new UserEditVM
            {
                Id = user.ID,
                Name = user.Name,
                DateOfBirth = user.DateOfBirth,
                Gender = user.Gender,
                Email = user.Email,
                Address = user.Address,
                Postalcode = user.Postalcode,
                TelNo = user.TelNo,
                LocationOfWork = user.LocationOfWork,
                Biography = user.Biography,
                KeySkills = user.KeySkills,
                Type = user.Type
            };
            return View(userEditVM);
        }

        [HttpPost]
        public IActionResult Edit(UserEditVM userViewModel)
        {
            if (ModelState.IsValid)
            {
                UserModel user = userRepository.GetUser(userViewModel.Id);
                user.Name = userViewModel.Name;
                user.DateOfBirth = userViewModel.DateOfBirth;
                user.Gender = userViewModel.Gender;
                user.Email = userViewModel.Email;
                user.Address = userViewModel.Address;
                user.Postalcode = userViewModel.Postalcode;
                user.TelNo = userViewModel.TelNo;
                user.LocationOfWork = userViewModel.LocationOfWork;
                user.Biography = userViewModel.Biography;
                user.KeySkills = userViewModel.KeySkills;
                user.Type = userViewModel.Type;

                userRepository.Update(user);
                // return RedirectToAction("Details", new { id = newUser.ID });
                return RedirectToAction("Index");
            }
            return View();
        }

        [HttpGet]
        [AllowAnonymous]
        public IActionResult Register()
        {
            return View();
        }

        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> Register(RegisterVM model)
        {
            if (ModelState.IsValid)
            {
                var user = new IdentityUser { UserName = model.Email, Email = model.Email };
                var result = await userManager.CreateAsync(user, model.Password);

                if (result.Succeeded)
                {
                   await signInManager.SignInAsync(user, isPersistent: false);
                    return RedirectToAction("index", "account");
                }
                
                foreach(var error in result.Errors)
                {
                    ModelState.AddModelError("", error.Description);
                }
            }
            return View(model);
        }

        [HttpGet]
        [AllowAnonymous]
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> Login(LoginVM model)
        {
            if (ModelState.IsValid)
            {
                var result = await signInManager.PasswordSignInAsync(model.Email, model.Password, model.RememberMe, false);
                if (result.Succeeded)
                {
                    return RedirectToAction("Index", "Account");
                }
                ModelState.AddModelError(string.Empty, "Login Unsuccessful");
            }
            return View(model);
        }

        [HttpPost]
        public async Task<IActionResult> Logout()
        {
            await signInManager.SignOutAsync();
            return RedirectToAction("Index", "Home");
        }

        [HttpGet]
        public IActionResult DeleteUser(int id)
        { 
            var getUserByID = userRepository.GetUser(id);

            if (getUserByID == null)
            {
                ViewBag.ErrorMessage = $"User = {id} does not exist.";
                return View("Error");
            }
            else
            {
                userRepository.Delete(id);
                return RedirectToAction("Index");
            }
        }


    }
}

