﻿using SportsAppMVC.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace SportsAppMVC.VM
{
    public class NewUserModelVM
    {
        
        [Required(ErrorMessage = "Enter your Name")]
        [MaxLength(50, ErrorMessage = "No characters above 50")]
        public string Name { get; set; }

        [Display(Name = "Date Of Birth")]
        public DateTime? DateOfBirth { get; set; }

        public string Gender { get; set; }

        [Display(Name = "Email Address")]
        [DataType(DataType.EmailAddress)]
        [Required(ErrorMessage = "Enter your Email")]
        public string Email { get; set; }

        [MaxLength(100, ErrorMessage = "No characters above 100")]
        [Required(ErrorMessage = "Enter your Address")]
        public string Address { get; set; }

        [Required(ErrorMessage = "Enter Postal Code")]
        [DataType(DataType.PostalCode)]
        public string Postalcode { get; set; }


        [Display(Name = "Telephone Number")]
        [DataType(DataType.PhoneNumber)]
        [Required(ErrorMessage = "Enter Telephone Number")]
        public string TelNo { get; set; }

        [MaxLength(50, ErrorMessage = "No characters above 50")]
        [Display(Name = "Location of work")]
        [Required(ErrorMessage = "Enter your location of work")]
        public string LocationOfWork { get; set; }

        [MaxLength(255, ErrorMessage = "No characters above 255")]
        [Display(Name = "Enter Biography")]
        public string Biography { get; set; }

        [MaxLength(40, ErrorMessage = "No characters above 40")]
        [Display(Name = "Describe your skills")]
        public string KeySkills { get; set; }

        [Display(Name = "Sport Type")]
        [Required(ErrorMessage = "Select a Sport type")]
        public SportsType? Type { get; set; }

    }
}
