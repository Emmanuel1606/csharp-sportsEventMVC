﻿using SportsAppMVC.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SportsAppMVC.VM
{
    public class ViewUserDetailsVM
    {
        public UserModel User { get; set; }
        public string PageTitle { get; set; }
    }
}
