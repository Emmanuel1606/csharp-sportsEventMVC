﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SportsAppMVC.VM
{
    public class UserEditVM : NewUserModelVM
    {
        public int Id { get; set; }
    }
}
